package com.example.projek_akhir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjekAkhirApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjekAkhirApplication.class, args);
	}

}
